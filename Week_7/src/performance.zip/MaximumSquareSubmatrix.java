public class MaximumSquareSubmatrix {

  // Returns the size of the largest contiguous square submatrix
  // of a[][] containing only 1s.
  public static int size(int[][] a) {
    // there have to be 2 or more positive set of cubes to be a
  }

  // Reads an n-by-n matrix of 0s and 1s from standard input
  // and prints the size of the largest contiguous square submatrix
  // containing only 1s.
  public static void main(String[] args) {}
}
