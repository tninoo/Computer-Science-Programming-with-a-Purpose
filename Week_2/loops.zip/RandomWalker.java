public class RandomWalker {
    public static void main(String[] args) {
        int distance = Integer.parseInt(args[0]);
        int current = 0;
        int max = 0;
        int steps = 0;
    
        //print this cordinate first
        System.out.println("(0, 0)");

        while (Math.abs(current) + Math.abs(max) != distance) {

            double random = Math.random();
            if (random < 0.25) current++;
            else if (random < 0.5) current--;
            else if (random < 0.75) max++;
            else max--;
        //print the rest of the cordinates
            System.out.println("(" + current + ", " + max + ")");
           // count
             steps++;
        }
        //total amount of steps 
        System.out.println("steps = " + steps);
    }
}
